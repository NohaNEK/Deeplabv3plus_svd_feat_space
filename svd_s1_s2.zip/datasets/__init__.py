from .voc import VOCSegmentation
from .cityscapes import Cityscapes
from .gta import GTA
from .gtav import GTAV
from .coco import COCO